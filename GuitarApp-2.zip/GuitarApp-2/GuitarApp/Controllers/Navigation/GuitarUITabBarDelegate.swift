//
//  GuitarUITabBarDelegate.swift
//  GuitarApp
//
//  Created by Gerald Stanford on 4/1/24.
//

import UIKit


/* Maybe obselete*/
/*
class GuitarUITabBarDelegate: NSObject, UITabBarControllerDelegate
{
   // var navigation: UINavigationController
    static let singleInstance = GuitarUITabBarDelegate()
    override private init()
    {
        super.init()
        
    }
    
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) 
    {
        if (tabBarController.selectedViewController is BLEViewControllerBase)
        {
            // assigns the current view as the new delegate for certain operations
            let view = tabBarController.selectedViewController as! BLEViewControllerBase
           // view.bleObject?.WriteModeSendOverBluetooth(view.SetDefaultGuitarMode())
           // print("Tabcontroller seleted")
        }
       
    }
    
    
}
*/
