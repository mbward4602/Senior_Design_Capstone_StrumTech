//
//  GuitarUINavigationDelegate.swift
//  GuitarApp
//
//  Created by Gerald Stanford on 3/19/24.
//

import UIKit


/* Maybe obselete*/
/*
 class GuitarUINavigationDelegate: NSObject, UINavigationControllerDelegate
 {
 // var navigation: UINavigationController
 static let singleInstance = GuitarUINavigationDelegate()
 override private init()
 {
 super.init()
 
 }
 
 func navigationController(_ navigationController: UINavigationController, didShow viewController: UIViewController, animated: Bool) {
 
 if (viewController is BLEViewControllerBase)
 {
 print("Nav controller called")
 
 // assigns the current view as the new delegate for certain operations
 // let view = viewController as! BLEViewControllerBase
 //view.bleObject?.delegate = view
 // view.checkMode()
 }
 else
 {
 print("HUH?")
 }
 }
 
 }
 */
