//
//  GuitarUINavigationController.swift
//  GuitarApp
//
//  Created by Gerald Stanford on 3/19/24.
//

import UIKit
/*
class GuitarUINavigationController: UINavigationController
{
    override init(rootViewController: UIViewController)
    {
        super.init(rootViewController: rootViewController)
        delegate = GuitarUINavigationDelegate()
        navigationController
    }

    override init(navigationBarClass: AnyClass?, toolbarClass: AnyClass?)
    {
        super.init(navigationBarClass: navigationBarClass, toolbarClass: toolbarClass)
    }

    override init(nibName: String?, bundle: Bundle?)
    {
        super.init(nibName: nibName, bundle: bundle )
    }
    
    required init?(coder: NSCoder)
    {
        super.init(coder: coder)
    }
}
*/
