//
//  GuitarModeEnum.swift
//  GuitarApp
//
//  Created by Gerald Stanford on 2/28/24.
//

import Foundation

enum GuitarModeEnum
{
    case tuner
    case chord
    case free
}
